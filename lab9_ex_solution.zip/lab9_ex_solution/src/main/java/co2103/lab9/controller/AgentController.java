package co2103.lab9.controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import co2103.lab9.Lab9Application;
import co2103.lab9.domain.Agent;

@Controller
public class AgentController {
	
	@InitBinder
	protected void initBinder(WebDataBinder binder) {
		binder.addValidators(new AgentValidator());
	}

	@GetMapping("/agents")
	public String agents(Model model) {
		model.addAttribute("agents", Lab9Application.agents);
		return "agents/list";
	}
	
	@RequestMapping("/newAgent")
	public String newAgent(Model model) {
		model.addAttribute("agent", new Agent());
		return "agents/form";
	}
	
	@PostMapping("/addAgent")
	public String addAgent(@Valid @ModelAttribute Agent agent, BindingResult result) {
		if (result.hasErrors()) {
			return "agents/form";
		}
		Lab9Application.agents.add(agent);
		return "redirect:/agents";
	}
	
	@GetMapping("/terminate")
	public String terminate(@RequestParam int agent) {
		Agent toTerminate = null;
		for(Agent a : Lab9Application.agents) {
			if (a.getId() == agent) {
				toTerminate = a;
			}
		}
		if (toTerminate != null) {
			Lab9Application.agents.remove(toTerminate);
		}
		return "redirect:/agents";
	}
}
