package co2103.lab9.controller;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import co2103.lab9.Lab9Application;
import co2103.lab9.domain.Agent;

public class AgentValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		return Agent.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		Agent a = (Agent) target;

		for (Agent ex : Lab9Application.agents) {
			if (a.getId() == ex.getId()) {
				errors.rejectValue("id", "", "ID already in use.");	
			}
		}
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "", "Your agent needs a name!");

		if ("UK".equals(a.getCountry())) {
			errors.rejectValue("country", "", "MI-6 deploy agents only in foreign countries");
		}

	}

}
