package co2103.lab9;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import co2103.lab9.domain.Agent;

@SpringBootApplication
public class Lab9Application {
	
	public static List<Agent> agents;

	public static void main(String[] args) {
		agents = new ArrayList<>();
		Agent a = new Agent();
		a.setId(1);
		a.setCountry("Germany");
		a.setName("Merkel");
		agents.add(a);
		
		a = new Agent();
		a.setId(2);
		a.setCountry("America");
		a.setName("Smith");
		agents.add(a);
		
		SpringApplication.run(Lab9Application.class, args);
	}

}
