package co2103.lab9;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import co2103.lab9.GenerateTasks;

public class PreparationTest {

	@Test
	public void userDefined() throws Exception {
		assertNotNull("No username was specified in application.properties.", GenerateTasks.getUser());
	}
}
